/*

	CITD_EDW_Duplicate_Objects.sql
	
	created:	20230818	Andy Rupp
	updated:

	include Data Mesh replication / naming standards
	don't forget to change schema + prefix name parts
	
	from	CITD_D3_PROD.S2_<Name>
	to 		CITD_D1_DEV.S2_<Name>
	
*/

select	'CREATE or REPLACE TABLE CORPITDATAxxx.Schema_xxx.'		
	||	TABLE_NAME
	||	' as select * from '
	||	TABLE_CATALOG	|| '.'
	||	TABLE_SCHEMA	|| '.'
	||	TABLE_NAME		|| ' '
	||	' where 1 = 2 '					-- 1=2 will only copy structure but NO content. deactive if CONTENT is needed
	||	' ;'
from    CORPITDATAPROD.INFORMATION_SCHEMA.TABLES
where	TABLE_CATALOG	= 'CORPITDATAPROD'
and		TABLE_SCHEMA	= 'EDW_LND_TB'
and		TABLE_TYPE		= 'BASE TABLE'
and     TABLE_NAME      like '%'
ORDER	by
		TABLE_CATALOG
,		TABLE_SCHEMA
,		TABLE_NAME
;

select	'CREATE or REPLACE VIEW  CORPITDATAxxx.Schema_xxx.'		
	||	TABLE_NAME
	||	' as select * from '
	||	TABLE_CATALOG	|| '.'
	||	TABLE_SCHEMA	|| '.'
	||	TABLE_NAME
	||	' ;'
from    INFORMATION_SCHEMA.VIEWS
where	TABLE_CATALOG	= 'CITD_D3_PROD'
and		TABLE_SCHEMA	= 'S2_DQ'
and		TABLE_TYPE		= 'VIEW'
ORDER	by
		TABLE_CATALOG
,		TABLE_SCHEMA
,		TABLE_NAME
;