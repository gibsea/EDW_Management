/*

	CITD_EDW_Create_User_Data_Team.sql
	
	created:	20230914	Andy Rupp
	updated:	

*/

CREATE or REPLACE USER "aadelaja"			PASSWORD = 'SLALOM2345$$' 	LOGIN_NAME = 'aadelaja@kinaxis.com'		FIRST_NAME = 'Ayoyinka'		LAST_NAME = 'Adelaja'		EMAIL = 'aadelaja@kinaxis.com'			MUST_CHANGE_PASSWORD = TRUE	DEFAULT_WAREHOUSE = 'COMPUTE_WH' DEFAULT_NAMESPACE = 'CITD_D1_DEV.S1_LND' COMMENT = 'Data Team Member'	;

CREATE or REPLACE USER "D4PBI"			PASSWORD = 'D4_PBI$$' 	LOGIN_NAME = 'D4PBI'		FIRST_NAME = 'D4'		LAST_NAME = 'PBI'		EMAIL = 'arupp@kinaxis.com'			MUST_CHANGE_PASSWORD = FALSE	DEFAULT_WAREHOUSE = 'COMPUTE_WH' DEFAULT_NAMESPACE = 'CITD_D4_DEV.S1_LND' COMMENT = 'PBI Service Account'	;
